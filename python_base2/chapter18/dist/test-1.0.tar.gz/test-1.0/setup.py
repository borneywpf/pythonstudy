from distutils.core import setup

setup(name = 'test', version = '1.0', description = 'test setup',
      author = 'borney',
      py_modules = ['test'])
